# CSC290
## A project for the course csc290.
#### Essential variables:
* screen_size = (int, int) -> (width, height)
* background = (int, int, int) -> colour of the background 
* red = (255, 0, 0) -> RGB code for red colour to simplify work
* blue = (0, 0, 255) -> RGB code for blue colour to simplify work
* green = (0, 255, 0) -> RGB code for green colour to simplify work
* player_size = 30 -> the size of the player in int. Needed to track collisions and resize the sprite
* enemy_y_gap = 20 -> the gap between enemies in int. Needed to form a wel defined structure of groups enemies
